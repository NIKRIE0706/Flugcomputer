import argparse
import logging
import time
from pathlib import Path

from config import DEFAULT_CONFIG, TelemetryConfig
from sensors.imu_icm20948 import ICM20948SensorSuite
from sensors.simulated import SimulatedSensorSuite
from storage import TelemetryStorage
from telemetry import TcpTelemetryClient


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Raspberry Pi telemetry capture")
    parser.add_argument("--run-name", default=time.strftime("%Y%m%d_%H%M%S"))
    parser.add_argument("--duration", type=float, default=None)
    parser.add_argument("--sample-rate", type=float, default=DEFAULT_CONFIG.sample_rate_hz)
    parser.add_argument("--output-dir", type=str, default=str(DEFAULT_CONFIG.output_dir))
    parser.add_argument("--hardware", action="store_true", help="Read real Raspberry Pi sensors instead of simulated data")
    parser.add_argument("--send", action="store_true", help="Send JSON lines to a laptop TCP receiver")
    parser.add_argument("--host", default=DEFAULT_CONFIG.tcp_host)
    parser.add_argument("--port", type=int, default=DEFAULT_CONFIG.tcp_port)
    return parser.parse_args()


def build_config(args: argparse.Namespace) -> TelemetryConfig:
    return TelemetryConfig(
        sample_rate_hz=args.sample_rate,
        output_dir=Path(args.output_dir),
        tcp_host=args.host,
        tcp_port=args.port,
        enable_network=args.send,
        use_simulation=not args.hardware,
    )


def main() -> None:
    args = parse_args()
    config = build_config(args)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    sensors = SimulatedSensorSuite() if config.use_simulation else ICM20948SensorSuite()
    telemetry = TcpTelemetryClient(config.tcp_host, config.tcp_port) if config.enable_network else None

    period_s = 1.0 / config.sample_rate_hz
    start = time.monotonic()
    next_sample_at = start

    logging.info("Starting run %s at %.1f Hz", args.run_name, config.sample_rate_hz)
    with TelemetryStorage(config.output_dir, args.run_name) as storage:
        try:
            while args.duration is None or time.monotonic() - start < args.duration:
                now = time.monotonic()
                if now < next_sample_at:
                    time.sleep(next_sample_at - now)
                    continue

                timestamp = time.monotonic() - start
                sample = sensors.read_sample(timestamp)
                storage.write(sample)
                if telemetry is not None:
                    telemetry.send(sample)

                next_sample_at += period_s
        except KeyboardInterrupt:
            logging.info("Stopping run after keyboard interrupt")
        finally:
            storage.flush()
            if telemetry is not None:
                telemetry.close()

    logging.info("Wrote %s and %s", storage.csv_path, storage.jsonl_path)


if __name__ == "__main__":
    main()
