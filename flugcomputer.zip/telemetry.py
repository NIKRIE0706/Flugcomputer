import logging
import socket

from data_model import TelemetrySample


class TcpTelemetryClient:
    def __init__(self, host: str, port: int, timeout_s: float = 0.2) -> None:
        self._address = (host, port)
        self._timeout_s = timeout_s
        self._socket: socket.socket | None = None

    def send(self, sample: TelemetrySample) -> None:
        if self._socket is None:
            self._connect()
        if self._socket is None:
            return

        try:
            self._socket.sendall(sample.to_json_line().encode("utf-8"))
        except OSError as exc:
            logging.warning("Telemetry send failed: %s", exc)
            self.close()

    def close(self) -> None:
        if self._socket is not None:
            self._socket.close()
            self._socket = None

    def _connect(self) -> None:
        try:
            sock = socket.create_connection(self._address, timeout=self._timeout_s)
        except OSError as exc:
            logging.debug("Telemetry receiver unavailable: %s", exc)
            return
        sock.settimeout(self._timeout_s)
        self._socket = sock
        logging.info("Telemetry connected to %s:%s", *self._address)
