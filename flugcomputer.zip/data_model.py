import json
from dataclasses import asdict, dataclass
from typing import Optional


@dataclass(frozen=True)
class GPSData:
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    altitude: Optional[float] = None
    speed: Optional[float] = None
    satellites: Optional[int] = None


@dataclass(frozen=True)
class TelemetrySample:
    timestamp: float
    pressure: Optional[float]
    temperature: Optional[float]
    ax: float
    ay: float
    az: float
    gx: float
    gy: float
    gz: float
    gps: GPSData

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json_line(self) -> str:
        return json.dumps(self.to_dict(), separators=(",", ":")) + "\n"


CSV_FIELDS = [
    "timestamp",
    "pressure",
    "temperature",
    "ax",
    "ay",
    "az",
    "gx",
    "gy",
    "gz",
    "gps_latitude",
    "gps_longitude",
    "gps_altitude",
    "gps_speed",
    "gps_satellites",
]


def sample_to_csv_row(sample: TelemetrySample) -> dict:
    gps = sample.gps
    return {
        "timestamp": f"{sample.timestamp:.6f}",
        "pressure": _format_optional(sample.pressure),
        "temperature": _format_optional(sample.temperature),
        "ax": f"{sample.ax:.6f}",
        "ay": f"{sample.ay:.6f}",
        "az": f"{sample.az:.6f}",
        "gx": f"{sample.gx:.6f}",
        "gy": f"{sample.gy:.6f}",
        "gz": f"{sample.gz:.6f}",
        "gps_latitude": _format_optional(gps.latitude),
        "gps_longitude": _format_optional(gps.longitude),
        "gps_altitude": _format_optional(gps.altitude),
        "gps_speed": _format_optional(gps.speed),
        "gps_satellites": "" if gps.satellites is None else str(gps.satellites),
    }


def _format_optional(value: Optional[float]) -> str:
    return "" if value is None else f"{value:.6f}"
