import math
import random

from data_model import GPSData, TelemetrySample


class SimulatedSensorSuite:
    def __init__(self, seed: int = 1) -> None:
        self._random = random.Random(seed)

    def read_sample(self, timestamp: float) -> TelemetrySample:
        wobble = math.sin(timestamp * 2.0)
        noise = self._random.uniform(-0.03, 0.03)
        return TelemetrySample(
            timestamp=timestamp,
            pressure=1008.3 - timestamp * 0.02 + noise,
            temperature=27.4 + 0.1 * wobble,
            ax=0.02 * wobble + noise,
            ay=-0.01 * wobble,
            az=9.80665 + 0.04 * wobble + noise,
            gx=0.01 * wobble,
            gy=-0.02 * wobble,
            gz=0.015 * wobble,
            gps=GPSData(),
        )
