from data_model import GPSData


class NullGPS:
    def read(self) -> GPSData:
        return GPSData()
