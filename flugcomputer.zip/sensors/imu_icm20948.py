import logging

from data_model import TelemetrySample
from .gps_null import NullGPS

G = 9.80665


class ICM20948SensorSuite:
    def __init__(self, gps: NullGPS | None = None) -> None:
        try:
            import adafruit_icm20x
            import board
        except ImportError as exc:
            raise RuntimeError(
                "ICM20948 dependencies are missing. Install board and adafruit-circuitpython-icm20x on the Raspberry Pi."
            ) from exc

        self._adafruit_icm20x = adafruit_icm20x
        self._gps = gps or NullGPS()
        i2c = board.I2C()

        try:
            self._icm = adafruit_icm20x.ICM20948(i2c, address=0x69)
            logging.info("ICM20948 detected at address 0x69")
        except ValueError:
            self._icm = adafruit_icm20x.ICM20948(i2c, address=0x68)
            logging.info("ICM20948 detected at address 0x68")

        self._icm.accelerometer_range = adafruit_icm20x.AccelRange.RANGE_16G
        self._icm.gyro_range = adafruit_icm20x.GyroRange.RANGE_500_DPS
        self._icm.accelerometer_data_rate_divisor = 0
        self._icm.gyro_data_rate_divisor = 0
        self._check_resting_acceleration()

    def read_sample(self, timestamp: float) -> TelemetrySample:
        ax, ay, az = self._icm.acceleration
        gx, gy, gz = self._icm.gyro
        return TelemetrySample(
            timestamp=timestamp,
            pressure=None,
            temperature=None,
            ax=ax,
            ay=ay,
            az=az,
            gx=gx,
            gy=gy,
            gz=gz,
            gps=self._gps.read(),
        )

    def _check_resting_acceleration(self) -> None:
        ax, ay, az = self._icm.acceleration
        resting_g = (ax * ax + ay * ay + az * az) ** 0.5 / G
        logging.info("IMU resting acceleration: %.3f g", resting_g)
        if not 0.9 < resting_g < 1.1:
            logging.warning("IMU resting acceleration is not near 1 g; check sensor configuration.")
