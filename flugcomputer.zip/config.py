from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class TelemetryConfig:
    sample_rate_hz: float = 50.0
    output_dir: Path = Path("runs")
    tcp_host: str = "0.0.0.0"
    tcp_port: int = 5000
    enable_network: bool = False
    use_simulation: bool = True


DEFAULT_CONFIG = TelemetryConfig()
