import csv
from pathlib import Path
from types import TracebackType

from data_model import CSV_FIELDS, TelemetrySample, sample_to_csv_row


class TelemetryStorage:
    def __init__(self, output_dir: Path, run_name: str) -> None:
        output_dir.mkdir(parents=True, exist_ok=True)
        self.csv_path = output_dir / f"{run_name}.csv"
        self.jsonl_path = output_dir / f"{run_name}.jsonl"
        self._csv_file = self.csv_path.open("w", newline="", encoding="utf-8")
        self._jsonl_file = self.jsonl_path.open("w", encoding="utf-8")
        self._writer = csv.DictWriter(self._csv_file, fieldnames=CSV_FIELDS)
        self._writer.writeheader()

    def write(self, sample: TelemetrySample) -> None:
        self._writer.writerow(sample_to_csv_row(sample))
        self._jsonl_file.write(sample.to_json_line())

    def flush(self) -> None:
        self._csv_file.flush()
        self._jsonl_file.flush()

    def close(self) -> None:
        self.flush()
        self._csv_file.close()
        self._jsonl_file.close()

    def __enter__(self) -> "TelemetryStorage":
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        self.close()
